Change logs:

=================================
Version 2.6 • Aug 11, 2017
=================================
1. Added: Option use ScrollMagic via Class css
(Now you can use for all Editor and Elements out of Page content)
2. Added: On or Off ScrollMagic on mobile

=================================
Version 2.5 • Aug 09, 2017
=================================
1. Added: Name ID
2. Added: TriggerHook
3. Added: PushFollowers
4: Added: Style for range and switch button

=================================
Version 2.3 • Apr 28, 2017
=================================
1. Add Bezier
2. Smooth for Image-sequence

=================================
Version 2.2.1 • Mar 28, 2017
=================================
1. Fixed Option for each elements
2. Added draw SVG
3. Add Image-sequence (GIF-like behaviour controlled by the scroll bar)

=================================
Version 2.0 • Mar 27, 2017
=================================
1. Added Scenes
2. Added Magic Composer
- Settings
	+ General
		* Duration
		* Offset
		* Pin
	+ Init CSS
		* TranslateX
		* TranslateY
		* TranslateZ
		* ScaleX
		* ScaleY
		* ScaleZ
		* Rotate
		* RotateX
		* RotateY
		* RotateZ
		* SkewX
		* SkewY
		* Color
		* Background Color
		* Opacity
	+ After scrolling
		* TranslateX
		* TranslateY
		* TranslateZ
		* ScaleX
		* ScaleY
		* ScaleZ
		* Rotate
		* RotateX
		* RotateY
		* RotateZ
		* SkewX
		* SkewY
		* Color
		* Background Color
		* Opacity
	+ Ease
		* Duration
		* Delay
		* Type ( 33 types )
	+ Class toggle
		* ON / OFF
		* Class CSS ( 75 classes )

3. Added Support Mobile

=================================
Version 1.3 • Mar 3, 2017
=================================
1. Fixed Show on Visual Composer’s Add Element dropdown
2. Added Smooth Scroll mode
3. Updated UI Backend
