<?php
if (!defined('ABSPATH')) {
    die;
}
?>
<div class="wrap bb_wrap bb_sm_settings" id="bb-vcvs-settings">
    <h2 class="bb-headtitle"><?php esc_html_e('ScrollMagic - Add new scene', 'bestbug') ?></h2>

	<div class="bb-container" id="BBSceneEditor">

	</div>

</div>
