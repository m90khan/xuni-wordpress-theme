<?php
if (!defined('ABSPATH')) {
    die;
}
?>
<div class="wrap bb_wrap bb_sm_settings" id="bb-vcvs-settings">
    <h2 class="bb-headtitle"><?php esc_html_e('Welcome to ScrollMagic 2.0', 'bestbug') ?></h2>

	<p>Congratulations! You are about to use ScrollMagic for WordPress ever - Scrolling animation builder plugin  editors by <a href="https://codecanyon.net/user/bestbug/portfolio" target="_blank">BestBug</a>.</p>

	<p>All products: <a href="https://codecanyon.net/user/bestbug/portfolio" target="_blank">https://codecanyon.net/user/bestbug/portfolio</a></p>

	<p>Facebook: <a href="https://www.facebook.com/BestBug.Official/" target="_blank">https://www.facebook.com/BestBug.Official/</a></p>

	<p>Email: <a href="mailto:bestbug.com@gmail.com" target="_blank">bestbug.com@gmail.com</a></p>

	<p>Thank you for use my product!</p>

</div>
